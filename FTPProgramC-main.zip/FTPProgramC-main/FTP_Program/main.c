#include "libs.h"

int main() {

    mainmenu();

    return 0;
}