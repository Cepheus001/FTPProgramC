#ifndef LIBRARIESFTP
#define LIBRARIESFTP

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include "buffclear.h"
#include "menu.h"
#include "createprof.h"

#endif